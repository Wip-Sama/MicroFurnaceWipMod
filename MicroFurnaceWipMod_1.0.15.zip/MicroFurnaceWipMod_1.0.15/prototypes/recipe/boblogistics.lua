require "prototypes.recipe.vanilla"
require "prototypes.recipe.tier4"
require "prototypes.recipe.tier5"
