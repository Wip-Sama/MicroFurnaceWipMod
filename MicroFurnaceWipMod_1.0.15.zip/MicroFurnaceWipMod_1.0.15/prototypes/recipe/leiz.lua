require "prototypes.recipe.vanilla"
require "prototypes.recipe.tier4"
