data:extend{
  {
    type = "recipe-category",
    name = "micro-furnace-smelting",
  },
  {
    type = "recipe-category",
    name = "micro-furnace-bunch-smelting",
  },
}
