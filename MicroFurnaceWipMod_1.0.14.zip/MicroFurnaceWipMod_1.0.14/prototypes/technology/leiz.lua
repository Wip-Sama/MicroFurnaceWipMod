require "prototypes.technology.vanilla"
require "prototypes.technology.tier4"
