data:extend{
  {
    type = "item-subgroup",
    name = "micro-furnace-smelting",
    group = "production",
    order = "a-a",
  }
}
